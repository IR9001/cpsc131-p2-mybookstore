# Project 2 Submission: Book Store (DLL Adapter)

Our submission for CPSC 131, Section 05, Project 2

# Group Information

* Irvin Rafael <irvin999rafael6@csu.fullerton.edu> 886334101
* Matthew Merrick <Merrick@csu.fullerton.edu> 987654321
* Esteban Tinajero <etin016@csu.fullerton.edu> 886500495
