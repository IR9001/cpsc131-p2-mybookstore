#ifndef MY_DOUBLY_LINKED_LIST_HPP
#define MY_DOUBLY_LINKED_LIST_HPP


/**
 * TODO: Implement DoublyLinkedList, its Node, and its Iterator!
 * 
 * I've left some methods filled out for you,
 * 	and stubbed out some structure, to reduce difficulty.
 * 
 * You may add or remove methods as you see fit,
 * 	as long as you can still pass all unit tests.
 * Although, it may be more difficult to do so. Your choice!
 * 
 * Notice we're inside a namespace here.
 * The DLL is inside a namespace called DoublyLinkedList,
 * 	which is itself inside a namespace called CPSC131
 * This means, if you'd like to play around with your class later,
 * 	you'll need to access it like so:
 * ::CPSC131::DoublyLinkedList::DoublyLinkedList<int> list;
 * 
 * Look into main.cpp and CPP_Tests.cpp for examples of using
 * 	the DLL and your BookStore. But don't worry too much, as you
 * 	only need to implement these classes
 * (main and tests are already done for you)
 */


//
#include <iostream>
#include <stdlib.h>
#include <stdexcept>


/**
 * Namespace for our classroom !
 */
namespace CPSC131 {
	/**
	 * Namespace to hold all things related to our DLL
	 */
	namespace DoublyLinkedList {
		/**
		 * Node class, which our DLL will use
		 * 
		 * The Professor realizes he could have made this an inline class (like the Iterator),
		 * but he is lazy.
		 */
		template <class T>
		class Node {
			public:
				
				/// CTORS: YOUR WELCOME
				Node() : prev_(nullptr), next_(nullptr) {}
				Node(T element) : element_(element), prev_(nullptr), next_(nullptr) {}
				Node(T element, Node* prev, Node* next) : element_(element), prev_(prev), next_(next) {}
				
				/// Set the pointer to the previous element
				void setPrevious(Node* prev) {
					prev_ = prev;
				}
				
				/// Set the pointer to the previous element
				void setPrev(Node* prev) {
					prev_ = prev;
				}
				
				/// Get a pointer to the previous element
				Node* getPrevious() {
					return prev_;
				}
				
				/// Get a pointer to the previous element
				Node* getPrev() {
					return prev_;
				}
				
				/// Set the pointer to the next node
				void setNext(Node* next) {
					next_ = next;
				}
				
				/// Get a pointer to the next node
				Node* getNext() {
					return next_;
				}
				
				/// Set the element this node holds
				void setElement(T element) {
					element_ = element;
				}
				
				/// Get the element this node holds
				T& getElement() {
					return element_;
				}
				
				/// Return a reference to the element
				T& operator*() {
					return element_;
				}
				
			private:
				T element_;
				Node* prev_;
				Node* next_;
		};
		
		/**
		 * Implement our DoublyLinkedList class !
		 */
		template <class T>
		class DoublyLinkedList {
			public:
				
				/**
				 * Nested Iterator class.
				 * This allows user code to refer to the Iterator's type as:
				 * 
				 * CPSC131::DoublyLinkedList::DoublyLinkedList<int>::Iterator
				 * 
				 * (as opposed to specifying the template argument two times)
				 */
				class Iterator {
					public:
						
						///	Constructor taking a head and tail pointer; YOUR WELCOME
						Iterator(Node<T>* head, Node<T>* tail) : head_(head), tail_(tail) {
							this->cursor_ = this->end();
						}
						
						///	Constructor taking a head, tail, and cursor pointer; YOUR WELCOME
						Iterator(Node<T>* head, Node<T>* tail, Node<T>* cursor) : head_(head), tail_(tail), cursor_(cursor) {}
						
						///	Get a pointer to the head node, or end() if this list is empty
						Node<T>* begin() {
							if( size_ == 0) { 		//checks if size is 0, if true calls end()
								return end();		// end() sets to nullptr
							} else {
								return head_;		//returns the head_ ptr
							}
						}
						
						///	Get a node pointer representing "end" (aka "depleted"). Probably want to just use nullptr.
						Node<T>* end() {
							return nullptr; //returns nullptr, end
						}
						
						///	Get the node this iterator is currently pointing to
						Node<T>* getCursor() {
							return cursor_; 	//returns current node, shows there is nothing in list
						}
						

						/**
						 * Assignment operator
						 * Return a copy of this Iterator, after modification
						 */
						Iterator& operator=(const Iterator& other) {

							if ( this != &other) {			//checks if they are the same
								//this->size_ = other.size_; //im not sure if we should use size_ because we have to implement it elsewhere
								this->head_ = other.head_;
								this->tail_ = other.tail_;
								this->cursor_ = other.cursor_;
							}								//copies all the private elements
							return *this;					//returns the copy
						}
						
						///	Comparison operator
						bool operator==(const Iterator& other) {
							if (cursor_ == other.cursor_) {			//checks if they are equal
								return true;									//ture if they are the same
							} else {
								return false;									//false if not
							}
						}
						///	Inequality comparison operator
						bool operator!=(const Iterator& other) {
							if (cursor_ != other.cursor_) {			//checks if they are inequal 
								return true;									//true if they are not the same
							} else {
								return false;									//false if they are the same
							}
						}
						
						/**
						 * Prefix increment operator
						 * Return a copy of this Iterator, after modification
						 */
						Iterator& operator++()
						{
							Iterator pre_plus_itr_temp = *this;
							pre_plus_itr_temp.cursor_ = pre_plus_itr_temp.cursor_->getNext();
							this->cursor_ = this->cursor_->getNext(); 				// we still have to move cursor for original
							return pre_plus_itr_temp;								//returns copy of modified iterator
						}
						
						/**
						 * Postfix increment
						 * Return a copy of this Iterator, BEFORE it was modified
						 */
						Iterator operator++(int)
						{
							Iterator post_plus_temp_itr = *this;				//creates a temp copy of our iterator
							this->cursor_ = this->cursor_->getNext();				//changes our cursor to point at the next element in our list
							return post_plus_temp_itr;						//returns the copy of our iterator before modification
						}
						
						/**
						 * Prefix decrement operator
						 * Return a copy of this Iterator, after modification
						 */
						Iterator& operator--()
						{
							Iterator pre_minus_temp_itr = *this;
							pre_minus_temp_itr.cursor_ = pre_minus_temp_itr.cursor_->getPrev();
							this->cursor_ = this->cursor_->getPrev();				//calls getPrev to get the previous cursor, going back in the list
							return pre_minus_temp_itr;											//returns post modification
						}
						
						/**
						 * Postfix decrement operator
						 * Return a copy of this Iterator BEFORE it was modified
						 */
						Iterator operator--(int)
						{
							Iterator post_minus_temp_itr =  *this;						//creating a copy of the iterator, that gets modified
							this->cursor_ = this->cursor_->getPrev();	    		//calls the getPrev
							
							return post_minus_temp_itr;								//returns before it was modified
						}
						
						/**
						 * AdditionAssignment operator
						 * Return a copy of the current iterator, after modification
						*/
						Iterator operator +=(size_t add)
						{
							Iterator add_temp_itr = *this;								//creates temp itr

							if ( add < 0 ) {
								throw std::range_error("can not pass negative value");		//checks if value is less than zero/negative
							}

							for ( std::size_t i = 0; i < add; i++) {						//for loop moves cursor however many times
								if (cursor_ == nullptr) {
									break;
								}
								add_temp_itr.cursor_ = cursor_->getNext();
								cursor_ = cursor_->getNext();

								//idk if we need to check if it will reach the null
							}


							return add_temp_itr;
						}
						/**
						 * SubtractionAssignment operator
						 * Return a copy of the current iterator, after modification
						 */
						Iterator operator -=(size_t add)
						{
							Iterator sub_temp_itr = *this;								//creates temp itr

							if ( add < 0 ) {
								throw std::range_error("can not pass negative value");		//checks if value is less than zero/negative
							}

							for ( std::size_t i = 0; i < add; i++) {						//for loop moves cursor however many times
								if (cursor_ == nullptr) {
									return sub_temp_itr;
								}
								sub_temp_itr.cursor_ = cursor_->getPrev();
								cursor_ = cursor_->getPrev();

								//idk if we need to check if it will reach the null
							}
							return sub_temp_itr;
						}
						
						/**
						 * AdditionAssignment operator, supporting positive or negative ints
						 */
						Iterator operator +=(int add)
						{
							Iterator add_temp_itr = *this;						

							if (add > 0) {
								for ( int i = 0; i < add; i++) {						
									if (cursor_ == nullptr) {
										return add_temp_itr;
									}
									add_temp_itr.cursor_ = cursor_->getNext();
									cursor_ = cursor_->getNext();
								} 
								return add_temp_itr;
							}
							else if ( add < 0) {
								for ( int i = 0; i < add; i++) {						
									if (cursor_ == nullptr) {
										return add_temp_itr;
									}
									add_temp_itr.cursor_ = cursor_->getPrev();
									cursor_ = cursor_->getPrev();
								} 
								return add_temp_itr;
							}
							return add_temp_itr;
						}
						
						/**
						 * SubtractionAssignment operator, supporting positive or negative ints
						 */
						Iterator operator -=(int subtract)
						{
							Iterator sub_temp_itr = *this;							//creates temp itr

							if (subtract > 0) {
								for (int i = 0; i < subtract; i++) {						//for loop moves cursor however many times
									if (cursor_ == nullptr) {
										return sub_temp_itr;
									}
									sub_temp_itr.cursor_ = cursor_->getPrev();
									cursor_ = cursor_->getPrev();
								} 
								return sub_temp_itr;
							}
							else if ( subtract < 0) {
								for ( int i = 0; i < subtract; i++) {						//for loop moves cursor however many times
									if (cursor_ == nullptr) {
										return sub_temp_itr;
									}
									sub_temp_itr.cursor_ = cursor_->getNext();
									cursor_ = cursor_->getNext();
								} 
								return sub_temp_itr;
							}
							return sub_temp_itr;
						}
						/**
						 * Dereference operator returns a reference to the ELEMENT contained with the current node
						 */
						T& operator*() {
							return cursor_->getElement();
						}
					
					private:
						
						/// Pointer to the head node
						Node<T>* head_ = nullptr;
						
						/// Pointer to the tail node
						Node<T>* tail_ = nullptr;
						
						/**
						 * Pointer to the cursor node.
						 * This is only one way of letting the iterator traverse the linked list.
						 * You can change to a different method if you wish (and can still pass unit tests)
						 */
						Node<T>* cursor_ = nullptr;
					
					/// YOUR WELCOME
					friend class DoublyLinkedList;
				};
				
				/// Your welcome
				DoublyLinkedList() {}
				
				///	Copy Constructor
				DoublyLinkedList(DoublyLinkedList& other) {
					if (other.head() == nullptr) {
						return;
					}

					Node<T>* cursor = other.head();
					while (cursor != nullptr) {
						/*
						* Delegate node creation and head_ / tail_ assignment to push_back().
						* Push_back() increases size by 1 so there is no need to re-assign size_ after the loop.
						*/
						push_back(cursor->getElement());
						cursor = cursor->getNext();
					}
				}
				
				/// DTOR: Your welcome
				~DoublyLinkedList() {
					this->clear();
				}
				
				/**
				 * Clear the list and assign the same value, count times.
				 * If count was 5, T was int, and value was 3,
				 * 	we'd end up with a list like {3, 3, 3, 3, 3}
				 */
				void assign(size_t count, const T& value) {
					clear();

					for (size_t i = 0; i < count; i++) {
						/*
						* Delegate node creation and head_ / tail_ assignment to push_back().
						* Push_back() increases size by 1 so there is no need to re-assign size_ after the loop.
						*/
						push_back(value);
					}
				}
				
				/**
				 * Clear the list and assign values from another list.
				 * The 'first' iterator points to the first item copied from the other list.
				 * The 'last' iterator points to the last item copied from the other list.
				 * 
				 * Example:
				 * 	Suppose we have a source list like {8, 4, 3, 2, 7, 1}
				 * 	Suppose first points to the 4
				 *	Suppose last points to the 7
				 * 	We should end up with our list becoming: {4, 3, 2, 7}
				 *
				 * If the user code sends out-of-order iterators,
				 * 	just copy from 'first' to the end of the source list
				 * Example: first=7, last=4 from the list above would give us:
				 * 	{7, 1}
				 */
				void assign(Iterator first, Iterator last) {

				}
				
				/// Return a pointer to the head node, if any
				Node<T>* head() {
					return head_;
				}
				
				/// Return a pointer to the tail node, if any
				Node<T>* tail() {
					return tail_;
				}
				
				/**
				 * Return an iterator that points to the head of our list
				 */
				Iterator begin() {
					Iterator headPos(head_, tail_, head_);

					return headPos;
				}
				
				/**
				 * Return an iterator that points to the last element (tail) of our list
				 */
				Iterator last() {
					Iterator tailPos(head_, tail_, tail_);

					return tailPos;
				}
				
				/**
				 * Should return an iterator that represents being past the end of our nodes,
				 * or just that we are finished.
				 * You can make this a nullptr or use some other scheme of your choosing,
				 * 	as long as it works with the logic of the rest of your implementations.
				 */
				Iterator end() {
					Iterator endPos(nullptr, nullptr, nullptr);

					return endPos;
				}
				
				/**
				 * Returns true if our list is empty
				 */
				bool empty() const {
					if (head_ != nullptr) {
						return false;
					}
					return true;
				}
				
				/**
				 * Returns the current size of the list
				 * Should finish in constant time!
				 * (keep track of the size elsewhere)
				 */
				size_t size() const {
					return size_;
				}
				
				/**
				 * Clears our entire list, making it empty
				 * Remember: All removal operations should be memory-leak free.
				 */
				void clear() {
					while(!empty()) {
						// Call pop_front() to delete all nodes in the list.
						pop_front();
					}
					size_ = 0;
					head_ = nullptr;
					tail_ = nullptr;
				}
				
				/**
				 * Insert an element after the node pointed to by the pos Iterator
				 * 
				 * If the list is currently empty,
				 * 	ignore the iterator and just make the new node at the head/tail (list of length 1).
				 * 
				 * If the incoming iterator is this->end(), insert the element at the tail
				 * 
				 * Should return an iterator that points to the newly added node
				 * 
				 * To avoid repeated code, it might be a good idea to have other methods
				 * 	rely on this one.
				 */
				Iterator insert_after(Iterator pos, const T& value) {
					Node<T>* cursor = pos.getCursor();
					Node<T>* insert_node = new Node<T>(value);

					if (!empty()) {
						/*
						* Inserting somewhere in between head and tail.
						* Change prev_ and next_ values for inserted node, and
						* the ones before it so that it can be traversed head to tail.
						*/
						insert_node->setPrev(cursor);
						insert_node->setNext(cursor->getNext());
						cursor->getNext()->setPrev(insert_node);
						cursor->setNext(insert_node);
						size_++;
					}
					else if (pos == end()) {
						// Inserting at the tail, delegate to push_back().
						push_back(value);
					}
					else {
						// Empty list, set head and tail to node.
						head_ = insert_node;
						tail_ = insert_node;
						size_++;
					}

					Iterator newPos(head_, tail_, insert_node);
					return newPos;
				}
				
				/**
				 * Insert a new element after the index pos.
				 * Should work with an empty list.
				 * 
				 * Should return an iterator pointing to the newly created node
				 * 
				 * To reduce repeated code, you may want to simply find
				 * 	an iterator to the node at the pos index, then
				 * 	send it to the other overload of this method.
				*/
				Iterator insert_after(size_t pos, const T& value) {
					// Create an iterator that moves to index pos, then pass to insert_after(Iterator, Const T).
					Iterator newPos(head_, tail_, head_);
					newPos += pos;

					return insert_after(newPos, value);
				}
				
				/**```````````
				 * Erase the node pointed to by the Iterator's cursor.
				 * 
				 * If the 'pos' iterator does not point to a valid node,
				 * 	throw an std::range_error
				 * 
				 * Return an iterator to the node AFTER the one we erased,
				 * 	or this->end() if we just erased the tail
				 */
				Iterator erase(Iterator pos) {
					if (pos.getCursor() == nullptr) {
						throw std::range_error("ERROR: Iterator does not point to a valid node.");
					}

					/*
					* Sourced from Dona Bein's DLinkedList class.
					* 
					* Cursor passes through two if-statements that checks for the Head / Tail.
					* Otherwise, assumes it is an arbitrary node and sets the Prev and Next for the
					* node before and after Iterator pos.
					*/
					Node<T>* cursor = pos.getCursor();

					if (pos.getCursor() == head_) {
						if (head_ == tail_ || head_ == nullptr || tail_ == nullptr) {
							head_ = nullptr;
							tail_ = nullptr;
						}
						else {
							head_ = head_->getNext();
							head_->setPrev(nullptr);
						}
					}
					else if (pos.getCursor() == tail_) {
						tail_ = tail_->getPrev();
						tail_->setNext(nullptr);
					}
					else {
						cursor->getNext()->setPrev(cursor->getPrev());
						cursor->getPrev()->setNext(cursor->getNext());
					}

					Iterator newPos(head_, tail_, cursor->getNext());
					delete pos.getCursor();
					size_--;

					return newPos;
				}
				
				/**
				 * Add an element just after the one pointed to by the 'pos' iterator
				 * 
				 * Should return an iterator pointing to the newly created node
				 */
				Iterator push_after(Iterator pos, const T& value) {
					Node<T>* temp_node = pos.getCursor();

					/*
					* Create a new node to be inserted into the list.
					* Check if node was inserted at the tail, if so set it to new tail.
					*/
					Node<T>* insert_node = new Node<T>(value, temp_node, temp_node->getNext());
					if (insert_node->getNext() != nullptr) {
						insert_node->getNext()->setPrev(insert_node);
					}
					else {
						tail_ = insert_node;
					}
					temp_node->setNext(insert_node);
					size_++;

					pos++;
					return pos;
				}
				
				/**
				 * Add a new element to the front of our list.
				 */
				void push_front(const T& value) {
					/*
					* Create a new node and insert before head_, then set head_ to new node.
					* Check if there is at least one node before calling setPrev().
					*/
					Node<T>* push_node = new Node<T>(value, nullptr, head_);
					if (head_ != nullptr) {
						head_->setPrev(push_node);
					}
					head_ = push_node;
					size_++;
				}
				
				/**
				 * Add an element to the end of this list.
				 * 
				 * Should return an iterator pointing to the newly created node.
				 */
				Iterator push_back(const T& value) {
					Node<T>* push_node = new Node<T>(value, tail_, nullptr);

					/*
					* Check if list is empty prior to insertion to prevent function call on NullPtr.
					* Otherwise, assume list has at least one node and call on setNext().
					*/
					if (size_ == 0) {
						head_ = push_node;
						tail_ = push_node;
					}
					else {
						tail_->setNext(push_node);
						tail_ = push_node;
					}

					// Create an iterator with the cursor pointing to the new tail.
					Iterator tailPos(head_, tail_, tail_);
					size_++;

					return tailPos;
				}
				
				/**
				 * Remove the node at the front of our list
				 * 
				 * Should throw an exception if our list is empty
				 */
				void pop_front() {
					if (size_ == 0) {
						throw std::range_error("ERROR: Cannot pop from an empty list.");
					}

				    Iterator targetPos(head_, tail_, head_);
					erase(targetPos);
				}
				
				/**
				 * Return a reference to the element at the front.
				 * 
				 * Throw an exception if the list is empty
				 */
				T& front() {
					if (size_ == 0) {
						throw std::range_error("ERROR: List is empty.");
					}

					return head_->getElement();
				}
				
				/**
				 * Return a reference to the element at the back.
				 * 
				 * Throw an exception if the list is empty
				 */
				T& back() {
					if (size_ == 0) {
						throw std::range_error("ERROR: List is empty.");
					}

					return tail_->getElement();
				}
				
				/**
				 * Return the element at an index
				 * 
				 * Should throw a range_error is out of bounds
				 */
				T& at(size_t index) {
					if (index < 0 || index >= size_) {
						throw std::range_error("ERROR: Index out of bounds.");
					}

					// Node pointer traverses the list until it reaches specified index.
					Node<T>* cursor = head();
					for (size_t i = 0; i < index; i++) {
						cursor = cursor->getNext();
					}

					return cursor->getElement();
				}
				
				/**
				 * Reverse the current list
				 * 
				 * It might be easy to consider the following:
				 * - Create a temp empty list
				 * - Iterate through the current list
				 * - For each item in the current list, push to the FRONT (not back)
				 * - Assign the current list to the temp list
				 * - Discard the temp list
				 */
				void reverse() {
					// Check if list has at least one node before attempting to reverse.
					if (head() != nullptr) {
						Node<T>* temp_node = head();

						Node<T>* cursor = head();
						while (cursor != nullptr) {

							/**
							 * Starting from the head, prev_ and next_ are swapped locations.
							 * Since they have been swapped, cursor is set to the prev(),
							 * which will be the new next_ after the head and tail are swapped.
							 */

							temp_node = cursor->getPrev();
							cursor->setPrev(cursor->getNext());
							cursor->setNext(temp_node);

							cursor = cursor->getPrev();
						}

						// Now that each node's prev_ and next_ have been swapped, head_ and tail_ are swapped.
						temp_node = head_;
						head_ = tail_;
						tail_ = temp_node;
					}
				}
				
				/**
				 * I bet you're happy I'm not making you do this.
				 * No tests will be run against this function,
				 * 	but feel free to try it out, as a challenge!
				 * 
				 * If I were doing this and didn't care too much for efficiency,
				 * 	I would probably create an extra helper function to swap two
				 * 	positions in the current list.
				 * Then I would simply sweep through the list bubble-sort style.
				 * Perhaps selection sort.
				 * 
				 * If you want a huge challenge, try implementing quicksort.
				 * 
				 * (but again, don't worry about this method; it will not be tested)
				 */
				void sort() {}
				
				/**
				 * Assignment operator
				 * 
				 * Clear this list and fill it with the others' values
				 * (by value, not by reference)
				 * 
				 * Return a reference to this list
				 */
				DoublyLinkedList<T>& operator =(DoublyLinkedList<T>& other) {
					if (this != &other) {
						clear();

						Node<T>* cursor = other.head();
						while (cursor != nullptr) {
							// Delete node creation and head_ / tail_ assignment to push_back().
							push_back(cursor->getElement());
							cursor = cursor->getNext();
						}
						size_ = other.size_;
					}
					return *this;
				}
				
				/**
				 * Return true if the lists are "equal"
				 * 
				 * "Equal" here is defined as:
				 * - Same size
				 * - Elements at the same indexes would return true for their own comparison operators
				 * 
				 * In other words: "They contain all the same values"
				 * (no need to be references to each other)
				 */
				bool operator ==(DoublyLinkedList<T>& other) {
					if (size_ == other.size_) {
						Node<T>* cursor_1 = head();
						Node<T>* cursor_2 = other.head();

					    // Compare values from this list and other list until not equal, else return true.
						while (cursor_1->getNext() != nullptr) {
							if (cursor_1->getElement() != cursor_2->getElement()) {
								return false;
							}
							cursor_1 = cursor_1->getNext();
							cursor_2 = cursor_2->getNext();
						}
						return true;
					}
					return false;
				}
				
				/**
				 * Return true if the lists are "not equal"
				 * 
				 * See the operator== stub for definition of "equal"
				 * 
				 * Probably want to avoid repeated code by relying on the other operator
				 */
				bool operator !=(DoublyLinkedList<T>& other) {
					// Call on and return the opposite of the equality operator.
					return !(*this == other);
				}
				
			private:
				Node<T>* head_ = nullptr;
				Node<T>* tail_ = nullptr;
				size_t size_ = 0;
		};
	}
}

#endif















































/// Yes, I'm aware it's spelled you're*
